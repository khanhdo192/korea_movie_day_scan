<?php

// override core en language system validation or define your own en language validation message
return [
	'id' => 'id',
	'required' => 'Vui lòng nhập {0}',
	'isNumberNoZero' => 'Phải là số tự nhiên',
	'methodNotAllowed' => 'Phương pháp truyền sai định dạng',
];