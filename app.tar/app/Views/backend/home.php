<div class="card">
	<div class="card-body">
		<h1>Chào mừng bạn tới hệ thống của Việt Tương Tác,</h1>
	</div>
</div>