<?php
	$urlHome = base_url();
	$urlUser = base_url('user');
?>
<div class="row">
	<div class="col-12">
		<div class="widget-page">
			<h1 class="title">Quản lý thành viên</h1>
			<ol class="breadcrumb">
				<li class="breadcrumb-item">
					<a href="<?= $urlHome; ?>">Trang chủ</a>
				</li>
				<li class="breadcrumb-item">
					<a href="<?= $urlUser; ?>">Thành viên</a>
				</li>
				<li class="breadcrumb-item active">
					<a href="javascript:void(0);">Tìm thành viên</a>
				</li>
			</ol>
		</div>
	</div>
	<div class="col-12">

	</div>
</div>