<?php namespace App\Controllers\API;

use App\Controllers\BaseController;

class Api extends BaseController
{
	
	public function __construct()
    {
		
	}
	
	public function index()
	{
		
	}
	
}